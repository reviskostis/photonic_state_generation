Several notebooks for testing GraphiQ,Jabalizer, Eulerian paths, shapes of adjacency matrices with min emitters etc.
Plotting the LC-classes with colors depending on the number of emitters.